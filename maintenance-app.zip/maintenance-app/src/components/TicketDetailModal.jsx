import { useState } from 'react'
import { supabase } from '../supabaseClient'
import { StatusBadge, PriorityBadge } from './Badges'

const STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed']

export default function TicketDetailModal({ ticket, onClose, onUpdated }) {
  const [status, setStatus] = useState(ticket.status)
  const [actualCost, setActualCost] = useState(ticket.actual_cost ?? '')
  const [notes, setNotes] = useState(ticket.admin_notes || '')
  const [saving, setSaving] = useState(false)
  const [photoIndex, setPhotoIndex] = useState(null)

  async function handleSave() {
    setSaving(true)
    await supabase
      .from('tickets')
      .update({
        status,
        actual_cost: actualCost === '' ? null : Number(actualCost),
        admin_notes: notes,
        resolved_at: status === 'Resolved' || status === 'Closed' ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', ticket.id)
    setSaving(false)
    onUpdated()
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">
          ×
        </button>
        <div className="modal-head">
          <span className="mono">#{ticket.id.slice(0, 8).toUpperCase()}</span>
          <StatusBadge status={ticket.status} />
          <PriorityBadge priority={ticket.priority} />
        </div>
        <h2 className="modal-title">{ticket.title}</h2>
        <p className="modal-meta">
          {ticket.category} · {ticket.location} · raised by {ticket.raised_by_profile?.full_name || 'unknown'}
        </p>
        {ticket.description && <p className="modal-desc">{ticket.description}</p>}

        {ticket.photos?.length > 0 && (
          <div className="modal-photos">
            {ticket.photos.map((url, i) => (
              <img key={i} src={url} alt="" onClick={() => setPhotoIndex(i)} />
            ))}
          </div>
        )}

        <div className="field-row">
          <div>
            <label className="field-label">Status</label>
            <select className="field-input" value={status} onChange={(e) => setStatus(e.target.value)}>
              {STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label">Actual cost (₹)</label>
            <input className="field-input" type="number" min="0" value={actualCost} onChange={(e) => setActualCost(e.target.value)} />
          </div>
        </div>

        <label className="field-label">Admin notes</label>
        <textarea
          className="field-input"
          rows={3}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Vendor assigned, resolution details, etc."
        />

        <button className="btn-primary" onClick={handleSave} disabled={saving}>
          {saving ? 'Saving…' : 'Save Changes'}
        </button>
      </div>

      {photoIndex !== null && (
        <div className="lightbox" onClick={() => setPhotoIndex(null)}>
          <img src={ticket.photos[photoIndex]} alt="" />
        </div>
      )}
    </div>
  )
}

import { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { StatusBadge, PriorityBadge } from '../components/Badges'
import TicketDetailModal from '../components/TicketDetailModal'

const STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed']

export default function AdminTickets() {
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('All')
  const [locationFilter, setLocationFilter] = useState('All')
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    const { data } = await supabase
      .from('tickets')
      .select('*, raised_by_profile:profiles!tickets_raised_by_fkey(full_name)')
      .order('created_at', { ascending: false })
    setTickets(data || [])
    setLoading(false)
  }

  const locations = ['All', ...new Set(tickets.map((t) => t.location))]
  const filtered = tickets.filter(
    (t) => (statusFilter === 'All' || t.status === statusFilter) && (locationFilter === 'All' || t.location === locationFilter)
  )

  async function handleUpdated() {
    setSelected(null)
    await load()
  }

  if (loading) return <div className="page">Loading…</div>

  return (
    <div className="page">
      <h1 className="page-title">All Tickets</h1>

      <div className="filter-row">
        <select className="field-input" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          {['All', ...STATUSES].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <select className="field-input" value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)}>
          {locations.map((l) => (
            <option key={l}>{l}</option>
          ))}
        </select>
        <span className="hint-text">
          {filtered.length} ticket{filtered.length !== 1 ? 's' : ''}
        </span>
      </div>

      <div className="ticket-table">
        <div className="ticket-table-head">
          <span>Ref</span>
          <span>Issue</span>
          <span>Outlet</span>
          <span>Raised by</span>
          <span>Priority</span>
          <span>Status</span>
        </div>
        {filtered.map((t) => (
          <button key={t.id} className="ticket-table-row" onClick={() => setSelected(t)}>
            <span className="mono">#{t.id.slice(0, 8).toUpperCase()}</span>
            <span className="truncate">{t.title}</span>
            <span>{t.location}</span>
            <span>{t.raised_by_profile?.full_name || '—'}</span>
            <span>
              <PriorityBadge priority={t.priority} />
            </span>
            <span>
              <StatusBadge status={t.status} />
            </span>
          </button>
        ))}
        {filtered.length === 0 && <p className="hint-text">No tickets match these filters.</p>}
      </div>

      {selected && <TicketDetailModal ticket={selected} onClose={() => setSelected(null)} onUpdated={handleUpdated} />}
    </div>
  )
}

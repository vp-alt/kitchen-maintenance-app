import { useState } from 'react'
import { supabase } from '../supabaseClient'
import { useAuth } from '../auth/AuthContext'
import PhotoUploader from '../components/PhotoUploader'

const CATEGORIES = ['Electrical', 'Plumbing', 'Refrigeration', 'Kitchen Equipment', 'AC/HVAC', 'Civil/Structural', 'Other']
const LOCATIONS = ['Delhi', 'Gurgaon', 'Noida', 'Bengaluru', 'Mumbai', 'Hyderabad']
const PRIORITIES = ['Low', 'Medium', 'High', 'Urgent']

export default function RaiseTicket() {
  const { profile } = useAuth()
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState(CATEGORIES[0])
  const [location, setLocation] = useState(profile?.location || LOCATIONS[0])
  const [priority, setPriority] = useState('Medium')
  const [estimatedCost, setEstimatedCost] = useState('')
  const [photos, setPhotos] = useState([])
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(null)
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      const ticketId = crypto.randomUUID()
      const photoUrls = []

      for (const p of photos) {
        const path = `${ticketId}/${p.name}`
        const { error: upErr } = await supabase.storage.from('ticket-photos').upload(path, p.blob, {
          contentType: 'image/jpeg',
        })
        if (upErr) throw upErr
        const { data } = supabase.storage.from('ticket-photos').getPublicUrl(path)
        photoUrls.push(data.publicUrl)
      }

      const { error: insErr } = await supabase.from('tickets').insert({
        id: ticketId,
        title,
        description,
        category,
        location,
        priority,
        estimated_cost: estimatedCost ? Number(estimatedCost) : null,
        raised_by: profile.id,
        photos: photoUrls,
      })
      if (insErr) throw insErr

      setDone(ticketId)
      setTitle('')
      setDescription('')
      setEstimatedCost('')
      setPhotos([])
    } catch (err) {
      setError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="page">
      <h1 className="page-title">Raise a Maintenance Ticket</h1>

      {done && <div className="banner-success">Ticket submitted. Reference #{done.slice(0, 8).toUpperCase()}</div>}
      {error && <div className="banner-error">{error}</div>}

      <form className="ticket-form" onSubmit={handleSubmit}>
        <label className="field-label">What's wrong?</label>
        <input
          className="field-input"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          placeholder="e.g. Walk-in chiller not cooling"
        />

        <label className="field-label">Details</label>
        <textarea
          className="field-input"
          rows={4}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="What happened, when, anything tried already"
        />

        <div className="field-row">
          <div>
            <label className="field-label">Category</label>
            <select className="field-input" value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATEGORIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label">Outlet</label>
            <select className="field-input" value={location} onChange={(e) => setLocation(e.target.value)}>
              {LOCATIONS.map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="field-row">
          <div>
            <label className="field-label">Priority</label>
            <select className="field-input" value={priority} onChange={(e) => setPriority(e.target.value)}>
              {PRIORITIES.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label">Estimated cost (₹, optional)</label>
            <input className="field-input" type="number" min="0" value={estimatedCost} onChange={(e) => setEstimatedCost(e.target.value)} />
          </div>
        </div>

        <label className="field-label">Photos</label>
        <PhotoUploader photos={photos} setPhotos={setPhotos} />

        <button className="btn-primary" type="submit" disabled={submitting}>
          {submitting ? 'Submitting…' : 'Submit Ticket'}
        </button>
      </form>
    </div>
  )
}

import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'

export default function Layout({ children }) {
  const { profile, signOut } = useAuth()
  const location = useLocation()
  const isAdmin = profile?.role === 'admin'

  function navItem(to, label) {
    const active = location.pathname === to
    return (
      <Link to={to} className={`nav-link ${active ? 'nav-link-active' : ''}`}>
        {label}
      </Link>
    )
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="brand">
          <span className="brand-mark">⚙</span>
          <span className="brand-text">MAINTENANCE DESK</span>
        </div>
        <nav className="app-nav">
          {!isAdmin && navItem('/', 'Raise Ticket')}
          {!isAdmin && navItem('/my-tickets', 'My Tickets')}
          {isAdmin && navItem('/admin', 'Dashboard')}
          {isAdmin && navItem('/admin/tickets', 'All Tickets')}
        </nav>
        <div className="user-pill">
          <div className="user-pill-text">
            <span className="user-name">{profile?.full_name}</span>
            <span className="user-role">{profile?.role}</span>
          </div>
          <button className="btn-ghost" onClick={signOut}>
            Log out
          </button>
        </div>
      </header>
      <main className="app-main">{children}</main>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useAuth } from '../auth/AuthContext'
import { StatusBadge, PriorityBadge } from '../components/Badges'

export default function MyTickets() {
  const { profile } = useAuth()
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    const { data } = await supabase
      .from('tickets')
      .select('*')
      .eq('raised_by', profile.id)
      .order('created_at', { ascending: false })
    setTickets(data || [])
    setLoading(false)
  }

  if (loading) return <div className="page">Loading…</div>

  return (
    <div className="page">
      <h1 className="page-title">My Tickets</h1>
      {tickets.length === 0 && <p className="hint-text">You haven't raised any tickets yet.</p>}
      <div className="ticket-list">
        {tickets.map((t) => (
          <div key={t.id} className="ticket-stub">
            <div className="ticket-stub-num">#{t.id.slice(0, 8).toUpperCase()}</div>
            <div className="ticket-stub-body">
              <div className="ticket-stub-title">{t.title}</div>
              <div className="ticket-stub-meta">
                {t.category} · {t.location}
              </div>
              {t.photos?.length > 0 && (
                <div className="ticket-stub-photos">
                  {t.photos.slice(0, 3).map((url, i) => (
                    <img key={i} src={url} alt="" />
                  ))}
                </div>
              )}
            </div>
            <div className="ticket-stub-tags">
              <StatusBadge status={t.status} />
              <PriorityBadge priority={t.priority} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

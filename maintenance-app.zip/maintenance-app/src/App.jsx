import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './auth/AuthContext'
import Login from './pages/Login'
import RaiseTicket from './pages/RaiseTicket'
import MyTickets from './pages/MyTickets'
import AdminDashboard from './pages/AdminDashboard'
import AdminTickets from './pages/AdminTickets'
import Layout from './components/Layout'

function Protected({ children, adminOnly = false }) {
  const { session, profile, loading } = useAuth()
  if (loading) return <div className="screen-center">Loading…</div>
  if (!session) return <Navigate to="/login" replace />
  if (adminOnly && profile?.role !== 'admin') return <Navigate to="/" replace />
  return children
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <Protected>
            <Layout>
              <RaiseTicket />
            </Layout>
          </Protected>
        }
      />
      <Route
        path="/my-tickets"
        element={
          <Protected>
            <Layout>
              <MyTickets />
            </Layout>
          </Protected>
        }
      />
      <Route
        path="/admin"
        element={
          <Protected adminOnly>
            <Layout>
              <AdminDashboard />
            </Layout>
          </Protected>
        }
      />
      <Route
        path="/admin/tickets"
        element={
          <Protected adminOnly>
            <Layout>
              <AdminTickets />
            </Layout>
          </Protected>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  )
}

import { useState } from 'react'

function compressImage(file, maxWidth = 1280, quality = 0.72) {
  return new Promise((resolve) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width)
        const canvas = document.createElement('canvas')
        canvas.width = Math.round(img.width * scale)
        canvas.height = Math.round(img.height * scale)
        const ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        canvas.toBlob((blob) => resolve(blob), 'image/jpeg', quality)
      }
      img.src = e.target.result
    }
    reader.readAsDataURL(file)
  })
}

export default function PhotoUploader({ photos, setPhotos, maxPhotos = 4 }) {
  const [busy, setBusy] = useState(false)

  async function handleFiles(e) {
    const files = Array.from(e.target.files).slice(0, maxPhotos - photos.length)
    if (!files.length) return
    setBusy(true)
    const compressed = await Promise.all(files.map((f) => compressImage(f)))
    const next = compressed.map((blob, i) => ({
      blob,
      previewUrl: URL.createObjectURL(blob),
      name: `photo_${Date.now()}_${i}.jpg`,
    }))
    setPhotos((prev) => [...prev, ...next].slice(0, maxPhotos))
    setBusy(false)
    e.target.value = ''
  }

  function removePhoto(idx) {
    setPhotos((prev) => prev.filter((_, i) => i !== idx))
  }

  return (
    <div className="photo-uploader">
      <div className="photo-grid">
        {photos.map((p, i) => (
          <div key={i} className="photo-thumb">
            <img src={p.previewUrl} alt={`upload-${i}`} />
            <button type="button" className="photo-remove" onClick={() => removePhoto(i)}>
              ×
            </button>
          </div>
        ))}
        {photos.length < maxPhotos && (
          <label className="photo-add">
            {busy ? '…' : '+ Add'}
            <input type="file" accept="image/*" multiple capture="environment" onChange={handleFiles} disabled={busy} hidden />
          </label>
        )}
      </div>
      <p className="hint-text">Up to {maxPhotos} photos. Opens the camera directly on mobile.</p>
    </div>
  )
}

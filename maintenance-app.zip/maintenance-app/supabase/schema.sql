-- ============================================================
-- Maintenance Ticket App — Supabase schema
-- Run this once in your Supabase project's SQL Editor.
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- PROFILES ----------
-- One row per user, auto-created when an account is added in Auth.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'user' check (role in ('user', 'admin')),
  location text,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;

-- Helper function (security definer) so policies can check "is this user
-- an admin" without recursive RLS lookups on profiles itself.
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$;

create policy "View own profile or any if admin"
  on public.profiles for select
  using (auth.uid() = id or public.is_admin());

-- ---------- TICKETS ----------
create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text not null,
  location text not null,
  priority text not null default 'Medium' check (priority in ('Low', 'Medium', 'High', 'Urgent')),
  status text not null default 'Open' check (status in ('Open', 'In Progress', 'Resolved', 'Closed')),
  estimated_cost numeric,
  actual_cost numeric,
  raised_by uuid references public.profiles(id),
  admin_notes text,
  photos jsonb not null default '[]'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  resolved_at timestamptz
);

alter table public.tickets enable row level security;

create policy "View own tickets or all if admin"
  on public.tickets for select
  using (raised_by = auth.uid() or public.is_admin());

create policy "Insert own tickets"
  on public.tickets for insert
  with check (raised_by = auth.uid());

create policy "Admins can update tickets"
  on public.tickets for update
  using (public.is_admin());

-- ---------- STORAGE (ticket photos) ----------
insert into storage.buckets (id, name, public)
values ('ticket-photos', 'ticket-photos', true)
on conflict (id) do nothing;

create policy "Authenticated users can upload ticket photos"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'ticket-photos');

create policy "Anyone can view ticket photos"
  on storage.objects for select
  using (bucket_id = 'ticket-photos');

-- ---------- AUTO-CREATE PROFILE ON SIGNUP ----------
-- When you add a user in Authentication > Users, set "User Metadata" to:
--   {"full_name": "Name Here", "role": "user", "location": "Delhi"}
-- This trigger reads that metadata and creates the matching profile row.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role, location)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    coalesce(new.raw_user_meta_data->>'role', 'user'),
    new.raw_user_meta_data->>'location'
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

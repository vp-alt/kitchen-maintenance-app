import { useState } from 'react'
import { supabase } from '../supabaseClient'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    setLoading(false)
    if (error) setError(error.message)
  }

  return (
    <div className="screen-center">
      <form className="login-card" onSubmit={handleSubmit}>
        <div className="brand brand-lg">
          <span className="brand-mark">⚙</span>
          <span className="brand-text">MAINTENANCE DESK</span>
        </div>
        <p className="login-sub">Sign in with the account your admin set up for you.</p>

        <label className="field-label">Email</label>
        <input className="field-input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus />

        <label className="field-label">Password</label>
        <input className="field-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />

        {error && <p className="field-error">{error}</p>}

        <button className="btn-primary" type="submit" disabled={loading}>
          {loading ? 'Signing in…' : 'Sign In'}
        </button>
      </form>
    </div>
  )
}

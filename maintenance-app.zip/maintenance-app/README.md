# Maintenance Desk

A maintenance ticket-raising app for your team. Staff raise tickets with photos
straight from their phone; you see everything on one dashboard with charts.

No approval chain — a user raises a ticket, it lands on the admin dashboard
immediately, you update its status and cost as work happens.

## What's inside

- **Raise Ticket** — staff pick a category, outlet, priority, attach up to
  4 photos (camera opens directly on mobile), and submit.
- **My Tickets** — staff see the status of everything they've raised.
- **Admin Dashboard** — stat cards + charts: tickets by status, by outlet,
  by category, and monthly spend.
- **All Tickets** — admin table with filters, click any row to view photos
  and update status / actual cost / notes.

Stack: **React (Vite) + Supabase + Vercel**. No separate backend server is
needed — Supabase handles the database, login, and photo storage directly,
so you can skip Render for this app and deploy just the two pieces below.

## 1. Set up Supabase (5 min)

1. Go to [supabase.com](https://supabase.com) → create a new project.
2. Open the **SQL Editor** → paste the entire contents of
   `supabase/schema.sql` → Run. This creates the tables, security rules,
   and the photo storage bucket in one go.
3. Go to **Project Settings → API** and copy:
   - Project URL
   - `anon` public key

## 2. Add your 20 users

Go to **Authentication → Users → Add user** in the Supabase dashboard, once
per person:

- Email + a temporary password (tell them to change it after first login,
  or use "send invite" if you've set up email).
- Under **User Metadata**, paste JSON like:
  ```json
  { "full_name": "Rahul Sharma", "role": "user", "location": "Gurgaon" }
  ```
  For yourself / other admins, use `"role": "admin"` instead.

A database trigger automatically creates their profile row from this
metadata — no extra step needed.

## 3. Run it locally

```bash
npm install
cp .env.example .env
# paste your Project URL and anon key into .env
npm run dev
```

Open the printed local URL, log in with one of the accounts you created.

## 4. Deploy to Vercel

1. Push this folder to a GitHub repo (or run `npx vercel` directly from
   this folder).
2. In Vercel: **New Project → Import** your repo.
3. Under **Environment Variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy. `vercel.json` is already set up so page refreshes/deep links
   work correctly.

Share the Vercel URL with your 20 users. On a phone, they can tap
**Add to Home Screen** in the browser menu for an app-like icon (the
manifest in `public/manifest.json` enables this).

## Notes for later

- Photos are compressed in the browser before upload (~150–300 KB each),
  so storage stays light even with daily use across outlets.
- To add more categories/outlets, edit the `CATEGORIES` / `LOCATIONS`
  arrays in `src/pages/RaiseTicket.jsx`.
- If you later want offline support or push notifications, that's a
  service-worker addition on top of the existing manifest — not required
  to launch.

import { useEffect, useState } from 'react'
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  Legend,
} from 'recharts'
import { supabase } from '../supabaseClient'

const STATUS_COLORS = { Open: '#F2A93B', 'In Progress': '#4C7A95', Resolved: '#4C9A6A', Closed: '#5A6472' }

function tally(rows, key) {
  return Object.entries(
    rows.reduce((acc, r) => {
      const k = r[key] || 'Unspecified'
      acc[k] = (acc[k] || 0) + 1
      return acc
    }, {})
  ).map(([name, value]) => ({ name, value }))
}

export default function AdminDashboard() {
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    load()
  }, [])

  async function load() {
    const { data } = await supabase.from('tickets').select('*')
    setTickets(data || [])
    setLoading(false)
  }

  if (loading) return <div className="page">Loading…</div>

  const total = tickets.length
  const open = tickets.filter((t) => t.status === 'Open').length
  const inProgress = tickets.filter((t) => t.status === 'In Progress').length
  const resolved = tickets.filter((t) => t.status === 'Resolved' || t.status === 'Closed').length
  const totalSpend = tickets.reduce((sum, t) => sum + (Number(t.actual_cost) || 0), 0)

  const statusData = tally(tickets, 'status')
  const locationData = tally(tickets, 'location')
  const categoryData = tally(tickets, 'category')

  const monthlySpend = Object.entries(
    tickets.reduce((acc, t) => {
      if (!t.actual_cost) return acc
      const key = new Date(t.created_at).toLocaleString('en-IN', { month: 'short', year: '2-digit' })
      acc[key] = (acc[key] || 0) + Number(t.actual_cost)
      return acc
    }, {})
  ).map(([name, value]) => ({ name, value }))

  return (
    <div className="page">
      <h1 className="page-title">Dashboard</h1>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-value">{total}</div>
          <div className="stat-label">Total Tickets</div>
        </div>
        <div className="stat-card stat-open">
          <div className="stat-value">{open}</div>
          <div className="stat-label">Open</div>
        </div>
        <div className="stat-card stat-progress">
          <div className="stat-value">{inProgress}</div>
          <div className="stat-label">In Progress</div>
        </div>
        <div className="stat-card stat-resolved">
          <div className="stat-value">{resolved}</div>
          <div className="stat-label">Resolved</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">₹{totalSpend.toLocaleString('en-IN')}</div>
          <div className="stat-label">Total Spend</div>
        </div>
      </div>

      <div className="chart-grid">
        <div className="chart-card">
          <h3 className="chart-title">Tickets by Status</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} paddingAngle={2}>
                {statusData.map((entry, i) => (
                  <Cell key={i} fill={STATUS_COLORS[entry.name] || '#8A93A0'} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3 className="chart-title">Tickets by Outlet</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={locationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2D3540" />
              <XAxis dataKey="name" stroke="#8A93A0" fontSize={12} />
              <YAxis stroke="#8A93A0" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#4C7A95" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3 className="chart-title">Tickets by Category</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={categoryData} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2D3540" />
              <XAxis type="number" stroke="#8A93A0" fontSize={12} allowDecimals={false} />
              <YAxis type="category" dataKey="name" stroke="#8A93A0" fontSize={12} width={110} />
              <Tooltip />
              <Bar dataKey="value" fill="#F2A93B" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3 className="chart-title">Monthly Spend</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={monthlySpend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2D3540" />
              <XAxis dataKey="name" stroke="#8A93A0" fontSize={12} />
              <YAxis stroke="#8A93A0" fontSize={12} />
              <Tooltip formatter={(v) => `₹${v.toLocaleString('en-IN')}`} />
              <Line type="monotone" dataKey="value" stroke="#F2A93B" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export function StatusBadge({ status }) {
  const map = {
    Open: 'badge-open',
    'In Progress': 'badge-progress',
    Resolved: 'badge-resolved',
    Closed: 'badge-closed',
  }
  return <span className={`badge ${map[status] || ''}`}>{status}</span>
}

export function PriorityBadge({ priority }) {
  const map = {
    Low: 'badge-low',
    Medium: 'badge-medium',
    High: 'badge-high',
    Urgent: 'badge-urgent',
  }
  return <span className={`badge ${map[priority] || ''}`}>{priority}</span>
}
